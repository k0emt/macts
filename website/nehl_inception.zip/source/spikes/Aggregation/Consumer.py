__author__ = 'k0emt'

# accepts the name of Q to subscribe to Qin in constructor
# does the wire up to subscribe to the Q
# specifies an abstract doOnDataReceived(data)