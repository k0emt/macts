#!/usr/bin/env python

__author__ = 'k0emt'

import Core

Core.MactsExchange.setup_message_exchanges("liaison","talker")