__author__ = 'k0emt'
import PlanningAgent

class GeneticAgent(PlanningAgent):
    """

    """
# SR15 The planning agent examines incoming data and creates a new TLS plan.
# SR16 The planning agent submits the plan to the Safety Agent for review.
# SR17 The Planning agent incorporates data that was shared from other
# collaboration agents regarding traffic that is flowing into this
# current intersection.
