__author__ = 'k0emt'
from Core import Agent

class PlanningAgent(Agent):
    """

    """

    # TODO SR 15 Planning Agent plans

    # TODO SR 16 Planning Agent submits plan to Safety Agent for Review